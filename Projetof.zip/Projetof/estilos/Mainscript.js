function form_log() {
   document.getElementById('log').visibility = 'visible'
}